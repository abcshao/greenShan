/*导航点击事件*/
$(function(){
	var a = false;
	$(".cover").hide();
	$(".control").click(function(){
		if(a==true){
			a=false;
			$(".cover").hide();
			$(".navList").hide();
		}else{
			
			a=true;
			$(".cover").show();
			$(".navList").show();
		}
	});
	$(".cover").click(function(){
		$(".cover").hide();
		$(".navList").hide();
		a=false;
	});
	
})

/*点击关闭表单*/
$(function(){
	$(".form b").click(function(){
		$(".form").hide();
	});
})

/*装修案例*/
/*装修案例点击切换*/
$(function(){
	var a = false;
	$(".fitmentBox .box div .estop").hide();
	
	var span = document.getElementsByClassName("span");
	
	var css1 = {
		borderColor: "#c30d23 #c30d23 transparent transparent",
		marginTop:0
				}
	var css2 = {
		borderColor: "transparent transparent #666666 #666666",
		marginTop:"-0.18rem"
	}
	for(var i=0;i<span.length;i++){
		span[i].onclick = function(){
			if(a==false){
				/*点击的时候隐藏所有遮罩层*/
				$(this).parent().siblings().children(".estop").hide();
				
				/*相邻span的样式初始化*/
				$(this).parent().siblings().children("span").css("color","#666666")
				$(this).parent().siblings().children("b").css(css2)
				/*span的样式变化*/
				$(this).css("color","#c30d23")
				$(this).siblings("b").css(css1)
				/*显示遮罩层*/
				$(this).siblings(".estop").show();
			}
			
		}
	}
	/*点击遮罩层消失*/
	$(".nin").click(function(){
		$(".fitmentBox .box div span").css("color","#666666")
		$(".fitmentBox .box div span").siblings("b").css(css2);
		$(".fitmentBox .box div span").siblings(".estop").hide();
	})
	/*点击选项*/
	$(".fitmentBox .box div .estop li").click(function(){
		$(".fitmentBox .box div span").css("color","#666666")
		$(".fitmentBox .box div span").siblings("b").css(css2);
		$(".fitmentBox .box div span").siblings(".estop").hide();
	})
	

	
});
/*案例介绍TAB介绍*/
$(function(){
	var css1 = {
		color:"#c30d23",
		borderBottom:"2px solid #c30d23"
	};
	var css2 = {
		color:"#666666",
		border:"none"
	};
	$(".tab .list2").hide();
	$(".tab .opus").css(css1);
	$(".tabList .opus").click(function(){
		$(this).css(css1);
		$(this).siblings().css(css2);
			$(".tab .list2").hide();
			$(".tab .list1").show();
	});
	$(".tabList .intro").click(function(){
		$(this).css(css1);
		$(this).siblings().css(css2);
			$(".tab .list1").hide();
			$(".tab .list2").show();
	});
	
})

/*快速报价*/
function fn(sum){
	var num = 0;
	var a = "";
	var li = document.getElementsByClassName("NumO");
	var timter = setInterval(function(){
		num+=8956;
		a = String(num);
		// alert(a.length);
		for(var i=0;i<li.length;i++){
			if(a.length<5){
				a= "0"+"0"+"0"+a;
				li[i].innerHTML=a.substring(i,i+1);
			}if(a.length<6){
				a= "0"+"0"+a;
				li[i].innerHTML=a.substring(i,i+1);
			}if(a.length<7){
				a= "0"+a;
				li[i].innerHTML=a.substring(i,i+1);
			}
			if(a.length<8){
				li[i].innerHTML=a.substring(i,i+1);
			}
			if(a.length>7){
				clearInterval(timter);
				a="9999999";
				li[i].innerHTML=a.substring(i,i+1);
			}
			if(Number(a)>=sum){
				clearInterval(timter);
				if(String(sum).length==7){
					li[i].innerHTML=String(sum).substring(i,i+1);
				}
				if(String(sum).length==6){
					sum="0"+String(sum);
					li[i].innerHTML=sum.substring(i,i+1);
				}
				if(String(sum).length==5){
					sum="0"+"0"+String(sum);
					li[i].innerHTML=sum.substring(i,i+1);
				}
				if(String(sum).length==4){
					sum="0"+"0"+"0"+String(sum);
					li[i].innerHTML=sum.substring(i,i+1);
				}			
			}
		}
	},0.0001);
}
/*在施工地*/
	$(function(){
		var state =document.getElementsByClassName("icoColor");
		var name ="";
		for(var i=0;i<state.length;i++){
			name = state[i].innerHTML;
			if(name=="已开工"){
				
			}
			if(name=="施工中"){
				
			}
			if(name=="已竣工"){
				
			}
		}
	})
/*装修指南*/
$(function(){
	var a = $("#Box>ol>li");
	var css1 = {
	color: "#666666"
	}
	var css2 = {
	color: "#c30d23"
	}
	for (var i=0;i<a.length;i++) {
		a[0].style.color = "#c30d23";

		a[i].onclick = function(){
			console.log($(this).html());
			$(this).siblings("li").css(css1);
			$(this).css(css2);
		}
		
	}
	
	
})

/*搜索--点击切换关键词*/
$(function(){
	var li = $(".searckBox>div>ul>li");
	var a = false;
	/*倒三角样式切换*/
	var css1 = {
		top:"0.2rem",
		borderColor: "transparent black black transparent"
	
	};
	var css2 = {
		top:"0.3rem",
		borderColor:"black transparent transparent black"
	};
	var css3 = {
		color:"#444444",
		fontWeight:100
	};
	$(".searckBox>div").hide();
	$(".searckBox>span").click(function(){
		if(a==false){
			$(".searckBox>span>s").css(css2);
			$(".searckBox>div").show();
			a=true;
		}else{
			$(".searckBox>span>s").css(css1);
			$(".searckBox>div").hide();
			$(".searckBox>div>ul>li").css(css3);
			a=false;
		}
		/*判断span文本和li文本一样，添加样式*/
		for(var i=0;i<li.length;i++){
			if($(".searckBox>span>span").html()==li[i].innerHTML){
				li[i].style.color = "#c30d23";
				li[i].style.fontWeight = "bold";
			}
			
		}
		
	})
	$(".searckBox>div>ul>li").click(function(){
		$(".searckBox>span>s").css(css1);
		$(".searckBox>div").hide();
		$(".searckBox>span>span").html($(this).html());
		$(".searckBox>div>ul>li").css(css3);
		
		if($(this).html()=="设计师"){
		$("#Box>.hotSearck>div>.hot_1").siblings("ol").hide();
		$("#Box>.hotSearck>div>.hot_1").show()
		}
		if($(this).html()=="案例"){
			$("#Box>.hotSearck>div>.hot_2").siblings("ol").hide();
			$("#Box>.hotSearck>div>.hot_2").show()
		}
		if($(this).html()=="工地"){
			$("#Box>.hotSearck>div>.hot_3").siblings("ol").hide();
			$("#Box>.hotSearck>div>.hot_3").show()
		}
		if($(this).html()=="图库"){
			$("#Box>.hotSearck>div>.hot_4").siblings("ol").hide();
			$("#Box>.hotSearck>div>.hot_4").show()
		}
		
		
		
		a=false;
	})
})
/*热门搜索切换*/
$(function(){
	var num = $("#Box>.hotSearck>div>ol");
	
	$("#Box>.hotSearck>div>ol").hide();
	var a = $(".searckBox>span>span").html();
	if(a=="设计师"){
		$("#Box>.hotSearck>div>.hot_1").siblings("ol").hide();
		$("#Box>.hotSearck>div>.hot_1").show()
	}
	if(a=="案例"){
		$("#Box>.hotSearck>div>.hot_2").siblings("ol").hide();
		$("#Box>.hotSearck>div>.hot_2").show()
	}
	if(a=="工地"){
		$("#Box>.hotSearck>div>.hot_3").siblings("ol").hide();
		$("#Box>.hotSearck>div>.hot_3").show()
	}
	if(a=="图库"){
		$("#Box>.hotSearck>div>.hot_4").siblings("ol").hide();
		$("#Box>.hotSearck>div>.hot_4").show()
	}
})

/*弹窗*/
$(function(){
	/*默认表单隐藏*/
	$(".NewForm").hide();
	/*点击最新优惠表单出现*/
	$(".NewBtn").click(function(){
		$(".NewForm").show();
	})
	
	
})